All of the sender.py, emulator.py and requester.py requires a helper file, named as utils.py.
The file is included in the Zip.
This file should reside in the same directory as the sender, emulator and requester (where it will be running).
For e.g.:
./
../
./test-1/
    sender.py
    utils.py
./test-2
    sender.py
    utils.py
emulator.py
utils.py


Request you to take this under consideration!
Thanks!